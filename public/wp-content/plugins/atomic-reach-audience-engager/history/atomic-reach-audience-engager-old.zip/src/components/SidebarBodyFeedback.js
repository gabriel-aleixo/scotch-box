import {Component} from "@wordpress/element";
import { Panel, PanelBody, PanelRow } from '@wordpress/components';
import {highlightIcon} from '../library/utils'

class SidebarFeedbackPanel extends Component {
    constructor() {
        super(...arguments);
        this.state={
            isHighlightOn: true,
        }
    }

    titlePanel(feedback){
        const items = [];
        const {measures,optimizeStatus,panelTitle} = this.props;

        if(optimizeStatus.isBusy){
            return ('');
        }

        measures.map((measure)=>{
            if (feedback.data.hasOwnProperty(measure)) {
                if(measure === "WordsCount") {
                    let message = this.getWordCountMessage('Word Count',measure,feedback.data[measure]);
                    feedback.data[measure].message = message;
                    items.push(this.getDetailsHTML(measure,feedback.data[measure]));
                }else if(measure === "PercentageParagraphsIdealWordCount"){
                    items.push(this.getDetailsWithButtonsHTML(measure,feedback.data[measure]));
                }
            }
        });


        return (
            <Panel className={'no-border'} >
                <PanelBody
                    title={panelTitle}
                    initialOpen={false}
                    className={'sidebar-title-header'}
                >
                    <PanelRow>
                        <ul className="collapse" id="criticalTitleIssues">
                            {items}
                        </ul>
                    </PanelRow>
                </PanelBody>
            </Panel>
        );
    };

    ToggleIsHighlightOnState(){
        this.setState((currentState) => ({
            isHighlightOn: !currentState.isHighlightOn,
        }));
    }

    getWordCountMessage(measureName, measure, feedback){

        let bucketRange =  feedback.bucket.split('-').map(e=>parseInt(e));
        let message = '';

        if(bucketRange.length === 1)
            bucketRange[1] = 2147483647; ///make the biggest int

        if(feedback.wordCount < bucketRange[0])
            message = `Increase your word count to ${feedback.bucket}`;
        if(feedback.wordCount > bucketRange[1])
            message = `Reduce your word count to ${feedback.bucket}`;

        return message
    }

    getDetailsWithButtonsHTML(measure,data){

        if(!data.message)
            return true;

        const {cardSelectionCallback} = this.props;
        const {isHighlightOn} = this.state;

        return (
            <React.Fragment key={measure}>
                <li className="list-group-item">
                    <div style={{marginRight:'5px'}} className={`dashicons ${(data.state) ? "blueColour dashicons-yes-alt" : "orangeColour  dashicons-dismiss"}`} />
                    <div>{data.message}</div>
                    <button className={`components-button ar-center is-default is-button ${(isHighlightOn) ? '' : 'highlighting'}`} onClick={()=>{
                        this.ToggleIsHighlightOnState();
                        cardSelectionCallback(measure,isHighlightOn);
                    }}>
                        {highlightIcon}
                    </button>
                </li>
            </React.Fragment>
        );
    }

    getDetailsHTML(measure,data){
        if(!data.message)
            return true;

        return (
            <React.Fragment key={measure}>
                <li className="list-group-item">
                    <div style={{marginRight:'5px'}} className={`dashicons ${(data.state) ? "blueColour dashicons-yes-alt" : "orangeColour  dashicons-dismiss"}`} />
                    <div>{data.message}</div>
                </li>
            </React.Fragment>
        );
    }

    render() {
        const {feedback,optimizeStatus} = this.props;

        return (
            <React.Fragment>
                {(optimizeStatus.hasClicked && feedback !== null) ? this.titlePanel(feedback) : ''}
            </React.Fragment>


        )
    }
}


export default SidebarFeedbackPanel;
