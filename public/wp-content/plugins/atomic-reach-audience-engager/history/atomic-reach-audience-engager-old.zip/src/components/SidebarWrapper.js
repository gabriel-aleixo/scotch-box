import {dispatch, select, subscribe} from "@wordpress/data";

import {
    ATOMICREACH_API_ANALYZE_ARTICLES,
    ATOMICREACH_API_NAMESPACE,
    ATOMICREACH_API_OPTIMIZE_ARTICLES,
    ATOMICREACH_API_PARAGRAPH_ANALYZE_ARTICLES,
    ATOMICREACH_PARAGRAPH_BREAK,
    ATOMICREACH_SIDEBAR_NAME,
    ATOMICREACH_STORE,
    ATOMICREACH_VALID_BLOCK_NAMES_ARRAY,
    OPTIMIZED_WORD_CLASS,
    SPELLING_GRAMMAR_CLASS,
    COMPLIANCE_CLASS,
} from "../constants";
import {Button, SelectControl, Tooltip} from '@wordpress/components';

import {
    cleanARHighlightingFromBlock,
    getHTMLFromBlock,
    highlightParagraphLength,
    highlightSpellingGrammar,
    highlightComplianceList,
    removeARMarkerTags,
    updateBlockContent,
    escapeCharForRegex
} from '../library/utils';
import {addToDictionary, getPopoverState, replaceActiveWord} from '../library/EditorLib';
import apiFetch from "@wordpress/api-fetch";
import {doRePositioningXYEditor, flagWordEditor} from '../library/popoverLib';
import GenericPopover from '../library/GenericPopover';
import SidebarTitleFeedback from "./SidebarTitleFeedback";
import SidebarBodyFeedback from "./SidebarBodyFeedback";
import {Component} from "@wordpress/element";


class SidebarWrapper extends Component {

    constructor() {
        super(...arguments);

        this.state = {
            profiles: {},
            selectedProfile: null,
            selectedProfileDetails:{},
            optimizeButton: {
                disabled: true,
                isBusy: false,
                hasClicked: false,
            },
            revertButton: {
                disabled: false,
                visible: false,
            },
            taskListFeedback: null,
            optimizeFeedback: null,
            paragraphsFeedback: null,
            hasChangedContent: false,
            isTyping: false,
            title: '',
            content: '',
            popoverState:{},

        };

        this.spellingIssueFeedback = {};
        this.opitmizedFeedback = {};
        this.clearingHiglights = false;
        this.atomicReachApiCallInProgress = false;
        this.componentIsMounted = true;
        this.unsubscribe = () => null;

        this.previousScore ={};
        this.previousOptimize ={};
        this.wordCount ={};

        this.storeOptimization = {};

        this.titleMeasures = [
            'TitleCharacterCount',
            'TitleWordsCount',
            'TitleContains5W1H',
            'TitleContainsNumbers',
            'TitlePolarity',
            'TitlePronounPerson',
            'TitleQuestion',
            'TitleSuperlatives',
            'TitleTopicsCount',
            'TitleTopicLocation',

        ];

        this.bodyMeasures = [
            'PercentageParagraphsIdealWordCount',
            'WordsCount',
        ];

        this.engagementNames = {
            GA_pageviews: 'Page Views',
            GA_uniquepageviews: 'Unique Views',
            GA_goalcompletionsall: 'Total Conversions',
            GA_avgTimeOnPage: 'Avg. Time on Page',
            GA_timeonpage: 'Time on Page',
            HS_ampViews: 'AMP Views',
            HS_ctaclick: 'CTA Clicks',
            HS_ctaRate: 'CTA Rate',
            HS_ctaviews: 'CTA Views',
            HS_entrances: 'Page Entrances',
            HS_leads: 'Leads',
            HS_marketingQualifiedLeads: 'Marketing Qualified Leads',
            HS_opportunities: 'Marketing Opportunities',
            HS_others: 'Others',
            HS_submissions: 'Submissions',
            HS_subscribers: 'Subscribers',
            HS_pageviews: 'Views',
            HS_pageTime: 'Time on Page',
            HS_timePerPageview: 'Time Per Pagview ',
            HS_submissionsPerPageview: 'View to Submission Rate',
            HS_contactsPerPageview: 'View to Contact Rate',
        };


        this.cardSelectionCallback = this.cardSelectionCallback.bind(this);

    }


    componentDidMount() {
        // console.log("Sidebar::comp did mount!", this.state, this.props);
        this.updateProfileState();

        this.updateTitleContentState();

        //https://developer.wordpress.org/block-editor/packages/packages-data/#subscribe
        this.unsubscribe = subscribe(() => this.subscribeListener());
        this.callParagraphFeedback();

        document.querySelector('.editor-writing-flow').addEventListener('click', (event) => {
            let mark = event.target;
            if (mark.classList.contains(SPELLING_GRAMMAR_CLASS))
                mark.arSuggestions = this.spellingIssueFeedback[mark.getAttribute('data-spelling-issue-id')];
            else if (mark.classList.contains(OPTIMIZED_WORD_CLASS))
                mark.arSuggestions = this.opitmizedFeedback[mark.getAttribute('data-optimize-id')];
            if(mark.classList.contains(SPELLING_GRAMMAR_CLASS) || (mark.classList.contains(OPTIMIZED_WORD_CLASS) || (mark.classList.contains(COMPLIANCE_CLASS)))) {
                const popoverState = getPopoverState(mark);
                this.setState({popoverState});
            }
        })


    }


    componentWillUnmount() {
        this.unsubscribe();
        this.removeARHighlighting();
        this.componentIsMounted = false;
    }


    componentDidUpdate(prevProps, prevState, snapshot) {

        const {profiles} = this.props;

        if(profiles.length !== prevProps.profiles.length){
            this.updateProfileState();
        }

        const {hasChangedContent,
            paragraphsFeedback,
            selectedProfile,
            optimizeFeedback
        } = this.state;



        if(hasChangedContent && !prevState.hasChangedContent) {

            const intervalToCallApi = setInterval(() => {
                if(!select('core/editor').isTyping() && !this.getAtomicReachApiCallInProgress()) {
                    this.updateTitleContentState();
                    clearInterval(intervalToCallApi);

                    if(selectedProfile === null){
                        // even if no prof is select, still call the api to get spelling/grammar
                        this.callParagraphFeedback();
                    }else {
                        this.callTitleDocumentApi();
                    }
                }
            }, 500);
        }

        if( JSON.stringify(paragraphsFeedback) !== JSON.stringify(prevState.paragraphsFeedback)){
            const {getBlocks} = select('core/editor');
            this.spellingIssueFeedback =  highlightSpellingGrammar(paragraphsFeedback, getBlocks() );
            this.complianceListFeedback =  highlightComplianceList(paragraphsFeedback, getBlocks() );
        }

        if( JSON.stringify(optimizeFeedback) !== JSON.stringify(prevState.optimizeFeedback) && Object.keys(optimizeFeedback).length > 0){
            this.setState({
                revertButton: {
                    disabled: false,
                    visible: true,
                }
            });
        }

    }

    callParagraphFeedback(){

        const requestArray = [];

        const {selectedProfile,taskListFeedback} = this.state;

        const {getBlocks} = select('core/editor');
        for(const block of getBlocks()) {
            if(!ATOMICREACH_VALID_BLOCK_NAMES_ARRAY.includes(block.name))
                continue;

            const paragraphArray = {};

            paragraphArray.contentTypeName = "Article";
            paragraphArray.environment = "PRODUCTION";
            paragraphArray.measureNamesArray = ["rtSpellingGrammar","rtComplianceList"];
            paragraphArray.content = encodeURIComponent(getHTMLFromBlock(block));
            paragraphArray.blockId = block.clientId;
            paragraphArray.blockName = block.name;

            if(selectedProfile){
                paragraphArray['profileId'] = selectedProfile;
            }

            if(taskListFeedback){
                const paragraphLength = taskListFeedback.data.PercentageParagraphsIdealWordCount;
                if(!paragraphLength.state){
                    paragraphArray.readabilityTargetBucket = taskListFeedback.data.Readability.target;
                    paragraphArray.measureNamesArray.push("rtParagraphLength")

                }
            }

            paragraphArray.measureNamesArray = JSON.stringify(paragraphArray.measureNamesArray);
            requestArray.push(paragraphArray);
        }

        const url = ATOMICREACH_API_NAMESPACE + ATOMICREACH_API_PARAGRAPH_ANALYZE_ARTICLES;

        this.setAtomicReachApiCallInProgress(true);
        apiFetch({
            path: url,
            method: 'POST',
            data: {
                requestArray: JSON.stringify(requestArray)
            }
        }).then((feedback) => {
            this.setAtomicReachApiCallInProgress(false);

            this.setState({
                paragraphsFeedback: feedback,
            })

        }).catch((error) => {
            console.log(error);
        })



    }

    closePopover(){
        const { popoverState } = this.state;
        this.setState({
            popoverState: {
                ...popoverState,
                showPopover: false,
            },
        });
    };

    subscribeListener() {

        if(!this.componentIsMounted) return;


        const {isSavingPost, isAutosavingPost, isPublishingPost } = select('core/editor');
        const {getActiveGeneralSidebarName} = select('core/edit-post');
        const {isTyping} = select('core/editor');




        // Ensure Atomic Reach sidebar is active and user has clicked on the optimize button atleast once.
        if(getActiveGeneralSidebarName() === ATOMICREACH_SIDEBAR_NAME && this.state.optimizeButton.hasClicked) {
            if(this.hasEditorContentUpdated()) {
                this.setState({
                    hasChangedContent: true,
                });
            }
        }

        if(getActiveGeneralSidebarName() === ATOMICREACH_SIDEBAR_NAME &&
            isTyping() &&
            this.state.optimizeButton.disabled === true &&
            this.state.optimizeButton.isBusy === false){
            this.setState({
                optimizeButton:{
                    ...this.state.optimizeButton,
                    disabled:false,
                },
            });
        }


        // When post is saving remove the highlighting.
        if ((isSavingPost() || isPublishingPost()) && !isAutosavingPost()) {
            this.removeARHighlighting();
        }

    }

    getContent() {
        const {getBlocks} = select('core/editor');
        let content = '';
        for(const block of getBlocks()) {
            content += getHTMLFromBlock(block);
        }
        return content;
    }

    updateTitleContentState() {

        // set hasChangedContent to false every time update state with up to date content.

        this.setState({
            title: select('core/editor').getEditedPostAttribute('title'),
            content: removeARMarkerTags(select('core/editor').getEditedPostContent()),
            hasChangedContent: false,
        });

    }

    updateProfileState() {
        this.setState({
            profiles: this.props.profiles,
        });
    }

    updateSelectedProfile(value) {

        const {profiles} = this.props;
        let profileDetails = {};

        profiles.forEach((profile)=>{
            if(value.profile == profile.value){
                profileDetails =profile
            }
        });


        this.setState({
            selectedProfile: value.profile,
            selectedProfileDetails:profileDetails,
            optimizeButton: {
                ...this.state.optimizeButton,
                disabled: isNaN(value.profile)
            }
        });


    }

    ProfilesDropdownList() {
        const {selectedProfile} = this.state;
        const {profiles} = this.props;
        return (
            <SelectControl
                // label={"Select Profile"}
                value={selectedProfile}
                options={profiles}
                onChange={
                    (profile) => {
                        if(profile !== 'Select a profile')
                            this.updateSelectedProfile({profile})
                    }
                }
            />
        )
    }

    OptimizeButtonClickHandler(event) {

        // disable and show spinner in the button
        this.setState({
            optimizeButton: {
                disabled: true,
                isBusy: true,
                hasClicked: true,
            },
            revertButton: {
                visible: false,
                disabled: false,
            },
        });

        this.storeOptimization = {};

        this.removeARHighlighting();

        this.callTitleDocumentForOriginalContentApi().then(()=>{
            this.callOptimizeApi();
        });




    }

    callOptimizeApi() {

        const {selectedProfile} = this.state;

        if(selectedProfile === null)
            return;

        this.setAtomicReachApiCallInProgress(true);
        const url = ATOMICREACH_API_NAMESPACE + ATOMICREACH_API_OPTIMIZE_ARTICLES;

        apiFetch({
            path: url,
            method: 'POST',
            data: {
                profileId: selectedProfile,
                content: this.getContent(),
            }
        }).then((feedback) => {
            this.setAtomicReachApiCallInProgress(false);
            console.log("feedback::", feedback);

            this.opitmizedFeedback = feedback;

            this.setState({
                optimizeFeedback: feedback,
                optimizeButton: {
                    ...this.state.optimizeButton,
                    isBusy: false,
                }
            });

            dispatch(ATOMICREACH_STORE).setOptimizeFeedback({
                optimizeFeedback: feedback
            });


            this.isOptimizedReadyNotice();
            this.processOptimizeFeedback();


        }).catch((err) => {
                console.error(err);
                this.reEnableOptimizeButton();
                this.setAtomicReachApiCallInProgress(false);
        });
    }

    /*
    * Until https://developer.wordpress.org/block-editor/developers/block-api/block-annotations/ apis are available
    * we have a custom method of doing highlighting.
    * */
    processOptimizeFeedback() {
        const {optimizeFeedback} = this.state;
        const {getBlocks} = select('core/editor');
        if(Object.keys(optimizeFeedback).length === 0) {
            console.log("no word replacement to do..exiting", optimizeFeedback);
            this.callTitleDocumentApi();
            return;
        }

        let totalOriginalContent = '';
        let thisTextContent = '';
        let paragraphCount = 0;


        let rangeAdjustment = 0;



        for(const block of getBlocks()) {

            paragraphCount++;
            this.storeOptimization[block.clientId] = {};

            thisTextContent = removeARMarkerTags(getHTMLFromBlock(block, true)).trim();

            if(thisTextContent === '')
                continue;

            thisTextContent += ATOMICREACH_PARAGRAPH_BREAK;

            // set the range
            // const range = [totalOriginalContent.length, (totalOriginalContent.length + thisTextContent.length)];
            const range = [totalOriginalContent.length, (totalOriginalContent.length + thisTextContent.length)];

            rangeAdjustment = 1; // after each paragraph

            const tokensFoundInRange = Object.entries(optimizeFeedback).filter(([key, token]) => {
                if(token.idx >= range[0] && token.idx < range[1]) {

                    this.storeOptimization[block.clientId][key] = {
                        token,
                    };

                    return [key, token];
                }
            });

            if(Object.keys(tokensFoundInRange).length === 0) {
                totalOriginalContent += thisTextContent;
                continue;
            }

            // replace tokens found in context

            let newText = '';
            const mapReplacementsForHighlighting = [];

            tokensFoundInRange.forEach((tokenFoundAtIndex) => {
                const key = tokenFoundAtIndex[0];
                const token = tokenFoundAtIndex[1];

                //if value exist in compliance list do not use itt
                if(token.text in this.complianceListFeedback)
                    return;

                const htmlReplacement = `*[${token.replacement}]*`;
                let pattern = `\\b(?!\\*\\[)${token.text}(?!\\]\\*)`;

                if(token.ws.length > 0) {
                    pattern += '\\b';
                }

                const regex = new RegExp(pattern);
                newText = (newText !== '') ? newText.replace(regex, htmlReplacement) : thisTextContent.replace(regex, htmlReplacement);

                mapReplacementsForHighlighting.push({
                    replacedWord: htmlReplacement,
                    feedback: optimizeFeedback[key],
                    key: key,
                    originalWord: token.text,
                });
            });


            let wordChangeCount = 0;

            mapReplacementsForHighlighting.forEach((replacement) => {
                const replacedWord = replacement.replacedWord.replace(/(\*|\[|\])/g, "");

                if(typeof this.wordCount[replacement.key]  === 'undefined')
                    this.wordCount[replacedWord] = 0;

                this.wordCount[replacedWord]++;

                if(newText.search(replacedWord) > 0) {
                    wordChangeCount++;
                }

                newText = newText.replace(replacement.replacedWord, "<armarker id=\'optmize_id_"+replacement.key +"' data-instance=\'"+this.wordCount[replacedWord]+"\' data-optimize-id=\'"+replacement.key +"\' class=\'"+OPTIMIZED_WORD_CLASS+"' >" + replacedWord + "</armarker>");

                // console.log(newText);
            });

            // console.log(`Words that have been optimized ${wordChangeCount} in paragraph number ${paragraphCount}`);

            // Replace the text in the editor.
            // dispatch('core/editor').updateBlockAttributes(block.clientId, {content: newText});
            // console.log("updating block with new text", block, newText);
            updateBlockContent(block, newText);

            totalOriginalContent += thisTextContent;
        }
    }

    replaceAt(index, replacement) {
        return this.substr(0, index) + replacement+ this.substr(index + replacement.length);
    }

    reHighlightOptimizedWords() {
        const {getBlocks} = select('core/editor');

        let thisTextContent = '';

        if(Object.keys(this.storeOptimization).length === 0) {
            console.log("no word replacement to do..exiting");
            return true;
        }

        for(const block of getBlocks()) {

            thisTextContent = removeARMarkerTags(getHTMLFromBlock(block, true)).trim();

            if(Object.keys(this.storeOptimization[block.clientId]).length === 0)
                return true;

            let newText = '';

            Object.entries(this.storeOptimization[block.clientId]).filter(([key, data]) => {

                const htmlReplacement = `*[${data.token.replacement}]*`;
                let pattern = `\\b(?!\\*\\[)${data.token.replacement}(?!\\]\\*)`;
                if(data.token.ws.length > 0) {
                    pattern += '\\b';
                }

                let regex = new RegExp(pattern);
                newText = (newText !== '') ? newText.replace(regex, htmlReplacement) : thisTextContent.replace(regex, htmlReplacement);

                newText = newText.replace(htmlReplacement,"<armarker id=\'optmize_id_"+key +"\' data-instance=\'"+this.wordCount[data.token.replacement]+"\'" +
                    "data-optimize-id=\'"+key +"\' class=\'"+OPTIMIZED_WORD_CLASS+"\' >" + data.token.replacement + "</armarker>" );

            });

            updateBlockContent(block, newText);

        }
    }

    revertHighlightedWords(){
        const {getBlocks} = select('core/editor');
        for(const block of getBlocks()) {

            const blockHTML         = getHTMLFromBlock(block, true);
            const DOM_nodes         = $('<div></div>').html( blockHTML );
            const optimizedWords    = DOM_nodes.find('.optimizedWord');

            if(optimizedWords.length < 1)
                continue;

            for(const word of optimizedWords){
                word.textContent = word.dataset.originalWord.trim();
                word.outerHTML = word.innerHTML.trim();
            }

            updateBlockContent(block, DOM_nodes.html());

        }

    }

    callTitleDocumentForOriginalContentApi(){
        const url = ATOMICREACH_API_NAMESPACE + ATOMICREACH_API_ANALYZE_ARTICLES;
        const {selectedProfile} = this.state;
        this.setAtomicReachApiCallInProgress(true);

        return new Promise((resolve) => {
            apiFetch({
                path: url,
                method: 'POST',
                data: {
                    profileId: selectedProfile,
                    title: select('core/editor').getEditedPostAttribute('title'),
                    contentHtml: this.getContent(),
                }
            }).then((feedback) => {

                this.previousScore[selectedProfile] = feedback.progress.valueNow;

                if (feedback.data.Arousal.state && feedback.data.Readability.state) {
                    this.previousOptimize.optmized = true;
                } else {
                    this.previousOptimize.optmized = false;
                }

                this.previousOptimize.Arousal = feedback.data.Arousal.state;
                this.previousOptimize.Readability = feedback.data.Readability.state;

                this.setAtomicReachApiCallInProgress(false);
                resolve();

            });
        }).catch((err) => {
            this.processTitleError(err)
        });

    }

    callTitleDocumentApi() {
        // Cancel if already a call in progress
        if(this.getAtomicReachApiCallInProgress())
            return;

        const {selectedProfile} = this.state;

        const title = select('core/editor').getEditedPostAttribute('title');

        this.setAtomicReachApiCallInProgress(true);

        const url = ATOMICREACH_API_NAMESPACE + ATOMICREACH_API_ANALYZE_ARTICLES;

        return apiFetch({
                path: url,
                method: 'POST',
                data: {
                    profileId: selectedProfile,
                    title,
                    contentHtml:  this.getContent(),
                }
        }).then((feedback) => {

            this.isPublishReadyNotice(feedback);
            this.setState({
                taskListFeedback: feedback,
            });

            dispatch(ATOMICREACH_STORE).setTaskListFeedback({
                taskListFeedback: feedback
            });
            // Do not remove the below log until PB approves.
            // PB needs the following log for his test.
            console.log('Arousal\tTargetBucket:[', feedback.data.Arousal.targetBucket, ']\tcurrentBucket:[', feedback.data.Arousal.bucket, "]\taverageArousalValue:["+feedback.data.Arousal.debug.averageArousalValue+"}\t|\tReadability\tTargetBucket:[", feedback.data.Readability.target, ']\tcurrentBucket:[', feedback.data.Readability.actual, "]\treadabilityScore:[", feedback.data.Readability.readabilityScore, "]");

            this.callParagraphFeedback();
            this.setAtomicReachApiCallInProgress(false);
        }).catch((err) => {
            console.error(err);
            this.reEnableOptimizeButton();
            this.setAtomicReachApiCallInProgress(false);
        });
    }

    getEngagementStr(){
        const {selectedProfileDetails} = this.state;

        let titleEngagement = this.engagementNames[selectedProfileDetails.titleEngagement];
        let bodyEngagement = this.engagementNames[selectedProfileDetails.bodyEngagement];
        let engagementStr = '';

        if(titleEngagement === bodyEngagement)
            engagementStr = titleEngagement;
        else
            engagementStr = `${titleEngagement} and ${bodyEngagement}`;

        return engagementStr;
    }

    isPublishReadyNotice(feedback) {
        const noticeId = "publishReadyNotice";
        const {selectedProfile, optimizeFeedback} = this.state;
        let scoreAfter = feedback.progress.valueNow;
        let scoreBefore = this.previousScore[selectedProfile];
        let engagementStr = this.getEngagementStr();

        this.removeNotice(noticeId);

        if(this.previousOptimize.optmized === true) {
            const noticeId = "optimizedReadyNotice";
            dispatch("core/notices")
                .createSuccessNotice('Your language is already optimized', {
                    id: noticeId
                });

        }else if(Object.keys(optimizeFeedback).length > 0){
            let optimizeRate = (((scoreAfter -scoreBefore) / scoreBefore) * 100).toFixed(2);
            dispatch("core/notices")
                .createSuccessNotice(`Your language is optimized by ${optimizeRate}% for ${engagementStr}`, {
                    id: noticeId
                })
        }
    }

    isOptimizedReadyNotice() {
        const noticeId = "optimizedReadyNotice";
        const {optimizeFeedback} = this.state;

        this.removeNotice(noticeId);
        if(Object.keys(optimizeFeedback).length === 0 && this.previousOptimize.optmized === false) {
            dispatch("core/notices")
                .createErrorNotice('This article could not be optimized for this profile', {
                    id: noticeId
                })
        }
    }

    removeNotice(noticeId){

        const notices = select("core/notices").getNotices();

        if(notices.length > 0) {
            for(const notice of notices) {
                if(notice.id === noticeId) {
                    dispatch("core/notices").removeNotice(noticeId);
                }
            }
        }
    }

    disableOptimizeButton() {
        this.setState({
            optimizeButton: {
                ...this.state.optimizeButton,
                disabled: true,
                isBusy: false,
            }
        })
    }

    reEnableOptimizeButton() {
        this.setState({
            optimizeButton: {
                ...this.state.optimizeButton,
                disabled: false,
                isBusy: false,
            }
        })
    }

    cardSelectionCallback(measure, isHighlightOn) {

        const {paragraphsFeedback} = this.state;

        if(isHighlightOn){
            highlightParagraphLength(paragraphsFeedback);
        }else{
            this.removeARHighlighting();
            this.reHighlightOptimizedWords();
            // this.processOptimizeFeedback()

        }
    }

    getAtomicReachApiCallInProgress() {
        return this.atomicReachApiCallInProgress;
    }

    setAtomicReachApiCallInProgress(state) {
        this.atomicReachApiCallInProgress = state;
    }

    hasEditorContentUpdated() {
        const {title, content} = this.state;
        const {getEditedPostContent, getEditedPostAttribute} = select('core/editor');

        return (title !== getEditedPostAttribute('title') || content !== removeARMarkerTags(getEditedPostContent()))
    }

    removeARHighlighting() {
        if(this.clearingHiglights){
            // console.log("cancel clearing highlighting because it is already running.");
            return;
        }
        this.clearingHiglights = true;
        const {getBlocks} = select('core/editor');
        for(const block of getBlocks()) {
            cleanARHighlightingFromBlock(block);
        }
        this.clearingHiglights = false;
    }

    removeTempARHighlighting() {
        this.hideARHighlighting()
    }


    hideARHighlighting() {
        document.querySelector('armarker').classList.add('hideHighlighting');
    }

    wordReplacedFromPopover() {
        this.setState({
            showPopover: false,
        });
    };

    render() {
        const {taskListFeedback,
            optimizeButton,
            popoverState,
            optimizeFeedback,
            revertButton,
        } = this.state;
        const editor = document.querySelector('.edit-post-layout__content');
        const {
            popoverFeedback,
            popoverOriginalWord,
            popoverId,
            showPopover,
            type,
            showAddToDictionary,
        } = popoverState;

        // console.log('-------------t a s k l i s t -------------');
        // console.log(taskListFeedback);

        return (
            <div id = {'atomicreach-sidebar-wrapper'}>
                <div id = {'atomicreach-profile-wrapper'} >{this.ProfilesDropdownList()} </div>
                <div id = {'atomicreach-optimize-button-wrapper'} >
                    <Tooltip text={'Optimize your language'} position={'bottom'}>
                        <Button
                            id = {'atomicreach-optimize-button'}
                            onClick = {
                                (e) => {
                                    e.preventDefault();
                                    this.OptimizeButtonClickHandler(e);}
                            }
                                    isBusy = {optimizeButton.isBusy}
                                    disabled = {optimizeButton.disabled}
                                    isLarge
                                 >
            {(optimizeButton.isBusy) ? 'Optimizing' : 'Optimize'}
            </Button>
            </Tooltip>
            {(revertButton.visible) ?
                <Button
                    id={'atomicreach-revert-button'}
                    disabled = {revertButton.disabled}
                    onClick = {(e)=>{
                        e.preventDefault();
                        this.setState({
                            revertButton: {
                                disabled: true,
                                visible: true,
                            }
                        });
                        this.revertHighlightedWords();
                    }
                        }
                    isLink

                >Revert Optimized Button
                </Button>
                    :null}</div>

                {/*<SidebarDocumentFeedback*/}
                {/*    panelTitle={'Improvements'}*/}
                {/*    feedback = {taskListFeedback}*/}
                {/*    optimizeStatus = {optimizeButton}*/}
                {/*    measures = {this.bodyMeasures}*/}
                {/*    cardSelectionCallback = {this.cardSelectionCallback}*/}
                {/*/>*/}

                <SidebarBodyFeedback
                    panelTitle={'Improvements'}
                    feedback = {taskListFeedback}
                    optimizeStatus = {optimizeButton}
                    measures = {this.bodyMeasures}
                    cardSelectionCallback = {this.cardSelectionCallback}
                />
                <SidebarTitleFeedback
                    titleMeasures = {this.titleMeasures}
                    feedback = {taskListFeedback}
                    optimizeStatus = {optimizeButton}
                />
                {ReactDOM.createPortal(
                    <GenericPopover
                        isOpen={showPopover}
                        type={type}
                        originalText={popoverOriginalWord}
                        originalClickable={optimizeButton.hasClicked}
                        popoverFeedback={popoverFeedback}
                        wordReplacedCallback={(e) => {
                            let target = document.getElementById(popoverId); // ensure that the document never losses the active element

                            replaceActiveWord(e.target,target);

                            const optimizedId = target.getAttribute('data-optimize-id');

                            let blockClientId = target.closest('.wp-block').id.replace('block-','');

                            this.storeOptimization[blockClientId][optimizedId].token={
                                ...this.storeOptimization[blockClientId][optimizedId].token,
                                replacement:target.innerHTML
                            };

                            let blockParagraph = target.closest('p');
                            const block = select("core/editor").getBlock(blockClientId);

                            updateBlockContent(block, blockParagraph.innerHTML);

                            this.wordReplacedFromPopover();
                            this.closePopover();
                        }}
                        close={() => {
                            this.closePopover();
                        }}
                        repositionPopover={doRePositioningXYEditor}
                        target={() => popoverId}
                        wordFlags
                        flagFunction={(replaceWord, feedbackType) => {
                            let target = document.getElementById(popoverId); // ensure that the document never losses the active element
                            let paragraphElement = target.closest('p');
                            flagWordEditor(replaceWord, target , feedbackType, paragraphElement,popoverOriginalWord);
                        }}
                        className="editor-popover"
                        message={''}
                        addToDictionary={showAddToDictionary && (() => {
                            this.closePopover();
                            let target = document.getElementById(popoverId);
                            addToDictionary(target).then(()=>{
                                target.outerHTML = target.innerHTML
                            });


                        })}
                    />,editor)
                }
        </div>
    )
    }


}

export default SidebarWrapper;
