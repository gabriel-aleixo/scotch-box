import {Component} from "@wordpress/element";
import { Panel, PanelBody, PanelRow } from '@wordpress/components';

class SidebarFeedbackPanel extends Component {
    constructor() {
        super(...arguments);
        this.titlePanel.bind(this);
        this.getDetailsHTML.bind(this);
        this.titleCategories = {
            TitleWordsCount:'Character and Word Count',
            TitleCharacterCount:'Character and Word Count',
            TitleContains5W1H:'Style',
            TitleContainsNumbers:'Style',
            TitlePolarity:'Style',
            TitlePronounPerson:'Style',
            TitleQuestion:'Style',
            TitleSuperlatives:'Style',
            TitleTopicLocation:'Topics',
            TitleTopicsCount:'Topics',
        }
    }

    componentDidMount() {
        // console.log("SidebarFeedbackPanel::comp did mount!", this.state, this.props);

    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // console.log("SidebarFeedbackPanel:: did update: ", prevProps, prevState, this.state, this.props);
        // this.updateProfileState();
    }

    titlePanel(feedback){

        const {titleMeasures,optimizeStatus} = this.props;

        if(optimizeStatus.isBusy){
            return ('');
        }


        let categoryList = {};
        let itemList = [];
        titleMeasures.map((measure)=>{

            if(typeof categoryList[this.titleCategories[measure]] === 'undefined')
                categoryList[this.titleCategories[measure]] = [];

            if (feedback.data.hasOwnProperty(measure)) {
                if(measure === "TitleTopicsCount" ) {
                    categoryList[this.titleCategories[measure]].push(this.getDetailsWithTagsHTML(measure, feedback.data[measure], feedback.data['Topics']));
                }else {
                    categoryList[this.titleCategories[measure]].push(this.getDetailsHTML(measure, feedback.data[measure]));
                }
            }
        });

        Object.keys(categoryList).forEach((category)=>{
            itemList.push (
                <div>
                    <h3> {category} </h3>
                    {categoryList[category]}
                </div>
            );

        });


        return (
            <Panel className={'no-border'} >
                <PanelBody
                    title="Title Insights"
                    initialOpen={false}
                    className={'sidebar-title-header'}
                >
                    <PanelRow>
                        <ul className="collapse" id="criticalTitleIssues">
                            {itemList}
                        </ul>
                    </PanelRow>
                </PanelBody>
            </Panel>
        );
    };

    getDetailsWithTagsHTML(measure,data,topics){
        if(!data.message)
            return true;

        let tags = "";

        if(topics.detail && topics.detail.length > 0){
            tags = topics.detail.map((tag,i) => <span key={i} className={"badge badge-blue mr-1"}>{tag}</span> );
            //@todo: Empty tag variable if condition is not true.
        }

        return (
            <React.Fragment key={measure}>
                <li className="list-group-item">
                    <span style={{marginRight:'5px'}} className={`dashicons ${(data.state) ? "blueColour dashicons-yes-alt" : "orangeColour  dashicons-dismiss"}`} />
                    {data.message}
                    <div>
                        {tags}
                    </div>
                </li>
            </React.Fragment>
        );
    }

    getDetailsHTML(measure,data){
        if(!data.message)
            return true;
        return (
            <React.Fragment key={measure}>
                <li className="list-group-item">
                    <span style={{marginRight:'5px'}} className={`dashicons ${(data.state) ? "blueColour dashicons-yes-alt" : "orangeColour  dashicons-dismiss"}`} />
                    {data.message}
                </li>
            </React.Fragment>
        );
    }

    render() {
        const {feedback,optimizeStatus} = this.props;
        return (
            <React.Fragment>
                {(optimizeStatus.hasClicked && feedback !== null) ? this.titlePanel(feedback) : ''}
            </React.Fragment>


        )
    }
}


export default SidebarFeedbackPanel;
