// https://developer.wordpress.org/block-editor/packages/packages-data/#actions


import {
    ATOMICREACH_STORE_FETCH_FROM_API,
    ATOMICREACH_STORE_TYPE_GET_PROFILES,
    ATOMICREACH_STORE_TYPE_SET_PROFILES,
    ATOMICREACH_STORE_TYPE_TASK_LIST_FEEDBACK,
    ATOMICREACH_STORE_TYPE_SET_TASK_LIST_FEEDBACK,
    ATOMICREACH_STORE_TYPE_OPTIMIZE_FEEDBACK,
    ATOMICREACH_STORE_TYPE_SET_OPTIMIZE_FEEDBACK
} from "../constants";


export const actions = {
    getProfiles(path) {
        return {
            type: ATOMICREACH_STORE_TYPE_GET_PROFILES,
            path,
        };
    },
    setProfiles(profiles) {
        return {
            type: ATOMICREACH_STORE_TYPE_SET_PROFILES,
            profiles,
        };
    },
    getTaskListFeedback(path) {
        return {
            type: ATOMICREACH_STORE_TYPE_TASK_LIST_FEEDBACK,
            path,
        };
    },
    setTaskListFeedback(taskListFeedback){
        return {
            type: ATOMICREACH_STORE_TYPE_SET_TASK_LIST_FEEDBACK,
            taskListFeedback
        };

    },
    getOptimizeFeedback(path) {
        return {
            type: ATOMICREACH_STORE_TYPE_OPTIMIZE_FEEDBACK,
            path,
        };
    },
    setOptimizeFeedback(optimizeFeedback) {
        return {
            type: ATOMICREACH_STORE_TYPE_SET_OPTIMIZE_FEEDBACK,
            optimizeFeedback,
        };
    },
    fetchFromAPI(path) {
        return {
            type: ATOMICREACH_STORE_FETCH_FROM_API,
            path,
        };
    },
};
