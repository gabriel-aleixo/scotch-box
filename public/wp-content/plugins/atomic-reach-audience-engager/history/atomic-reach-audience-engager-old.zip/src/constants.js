
export const ATOMICREACH_STORE = "atomicreach/store";
export const ATOMICREACH_STORE_TYPE_GET_PROFILES = "GET_PROFILES";
export const ATOMICREACH_STORE_TYPE_SET_PROFILES = "SET_PROFILES";
export const ATOMICREACH_STORE_TYPE_TASK_LIST_FEEDBACK = "TASK_LIST_FEEDBACK";
export const ATOMICREACH_STORE_TYPE_SET_TASK_LIST_FEEDBACK = "SET_TASK_LIST_FEEDBACK";
export const ATOMICREACH_STORE_TYPE_OPTIMIZE_FEEDBACK = "OPTIMIZE_FEEDBACK";
export const ATOMICREACH_STORE_TYPE_SET_OPTIMIZE_FEEDBACK = "SET_OPTIMIZE_FEEDBACK";



export const SPELLING_GRAMMAR_CLASS = "arSpellingGrammar";
export const COMPLIANCE_CLASS = "complianceWord";
export const OPTIMIZED_WORD_CLASS = "optimizedWord";



export const GRAMMAR_POPOVER = 'GRAMMAR_POPOVER';
export const OPTIMIZE_API_POPOVER = 'OPTIMIZE_API_POPOVER';


export const ATOMICREACH_STORE_FETCH_FROM_API = 'FETCH_FROM_API';

export const ATOMICREACH_API_NAMESPACE = "/atomicreach/v1";
export const ATOMICREACH_API_GET_PROFILES = "/get-profiles/";
export const ATOMICREACH_API_OPTIMIZE_ARTICLES = "/optimize/article/";
export const ATOMICREACH_API_ANALYZE_ARTICLES = "/titleDocumentAnalyze/article/";
export const ATOMICREACH_API_PARAGRAPH_ANALYZE_ARTICLES = "/paragraphAnalyze/article/";
export const ATD_TEXT_ANALYZE_URL = '/grammar/atd-info/';
export const ADD_DICTIONARY = '/dictionary/add/';
export const FLAG_WORD = '/optimize/flag/';

export const ATOMICREACH_SIDEBAR_NAME =  "atomicreach-sidebar/atomicreach-sidebar";

export const ATOMICREACH_VALID_BLOCK_NAMES_ARRAY = ["core/list","core/paragraph","core/heading","core/freeform"];

export const ATOMICREACH_PARAGRAPH_BREAK = "\n\n";
