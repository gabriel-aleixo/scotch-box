// https://redux.js.org/basics/reducers
// https://developer.wordpress.org/block-editor/packages/packages-data/#reducer

import {
    ATOMICREACH_STORE_TYPE_GET_PROFILES,
    ATOMICREACH_STORE_TYPE_SET_PROFILES,
    ATOMICREACH_STORE_TYPE_TASK_LIST_FEEDBACK,
    ATOMICREACH_STORE_TYPE_SET_TASK_LIST_FEEDBACK,
    ATOMICREACH_STORE_TYPE_OPTIMIZE_FEEDBACK,
    ATOMICREACH_STORE_TYPE_SET_OPTIMIZE_FEEDBACK,
} from "../constants";

const initialState = {
    userRoles: {},
    profiles: {},
    taskListFeedback: null,
    optimizeFeedback: null,
};

export const reducer = (state = initialState, action) => {

    // console.log("== Reducer: ", state, action);

    switch(action.type) {
        case ATOMICREACH_STORE_TYPE_GET_PROFILES:
            return {
                ...state,
                profiles: action.profiles,
            };
        case ATOMICREACH_STORE_TYPE_SET_PROFILES:
            return {
                ...state,
                profiles: action.profiles,
            };
        case ATOMICREACH_STORE_TYPE_TASK_LIST_FEEDBACK:
            return {
                ...state,
                taskListFeedback: action.taskListFeedback,
            };
        case ATOMICREACH_STORE_TYPE_SET_TASK_LIST_FEEDBACK:
            return {
                ...state,
                taskListFeedback: action.taskListFeedback,
            };
        case  ATOMICREACH_STORE_TYPE_OPTIMIZE_FEEDBACK:
            return {
                ...state,
                optimizeFeedback: action.optimizeFeedback,
            };
        case ATOMICREACH_STORE_TYPE_SET_OPTIMIZE_FEEDBACK:
            return {
                ...state,
                optimizeFeedback: action.optimizeFeedback,
            };

    }

    return state;
}
