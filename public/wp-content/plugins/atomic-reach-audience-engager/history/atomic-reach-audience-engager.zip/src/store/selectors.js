// https://developer.wordpress.org/block-editor/packages/packages-data/#selectors
export const selectors = {
    getProfiles(state) {
        const {profiles} = state;
        return profiles;
    },
    getTaskListFeedback(state) {
        console.log("selectors getTaskList", state);
        const {taskListFeedback} = state;
        return taskListFeedback;
    },
    getOptimizeFeedback(state) {
        console.log("selector: ",state);
        const {optimizeFeedback} = state;
        return optimizeFeedback;
    }
};
